# SBae_FinalProject
Samantha Bae
2342931
sabae@chapman.edu
CPSC 408 - 02
Final Project

Source Files:
-app.py
-helper.py

References
- Notes
- Zybooks

Known Errors:
- no errors

Tools to install:
pandas

Imports:
import mysql.connector
from mysql.connector.constants import ClientFlag
import pandas as pd
import sqlite3
from helper import helper

Public IP address:
34.135.120.108
